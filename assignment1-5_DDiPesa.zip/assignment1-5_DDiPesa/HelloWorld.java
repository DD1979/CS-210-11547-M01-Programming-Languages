// David A. DiPesa:  05/10/2024 - Writing an application to print "Hello, World!" in Java //

// FileName:  HelloWorld.java

public class HelloWorld { // Declare a class here //
	
	public static void main (String args[]) // Main Method //
	{

		System.out.println("Hello, World!"); // Prints Hello, World! //
		
	} // End of Main Method //
} // End of Program //