## David A. DiPesa: 05/09/2024 - Writing an application to print "Hello, World!" in Python ##

# Outputs Hello, World!
print ("Hello, World!")

# Python is a loose language so its easier to print out with it #