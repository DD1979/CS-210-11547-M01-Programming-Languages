/* Assignment 2-3:  What's buggung you? */

/*
 * Calculator.cpp
 *
 *  Date: 05/15/2024
 *  Author: David A. DiPesa
 */

#include <iostream>
using namespace std;

int main() // Void Removed.  We cannot use this to return any values. //
{
	// char statement[100]; - This is not needed for anything.  Commented out for now. //
	double op1, op2; // Change int to double for running all numbers. //
	char operation;
	char answer = 'Y';  //  Added a semicolon here and changed the quotes to singles  //
	while ((answer == 'y') || (answer == 'Y'))  // Added a brace and fixed the While statement //
	{
		cout << "Enter expression" << endl; // Fixed the spacing of the << //
		cin >> op1 >> operation >> op2; // Switched the order of op1 and op2 here //

		if (operation == '+') {  // Needs a brace here so I added it.  "+" changed to '+' //
			cout << op1 << " + " << op2 << " = " << op1 + op2 << endl;  // Arrows were the wrong way. Fixed this issue. //
		}  // Added the brace to finish this If statement //

		if (operation == '-') {  // Needs a brace here so I added it. //
			cout << op1 << " - " << op2 << " = " << op1 - op2 << endl; // Fixed the first >> to be << //
		}  // Added the brace to finish this If statement //

		if (operation == '*') {  // Needs a brace here so I added it. //
			cout << op1 << " * " << op2 << " = " << op1 * op2 << endl;  //  Added a semicolon and fixed "/" to be "*" instead //
		}  // Added the brace to finish this If statement //

		if (operation == '/') {  // Needs a brace here so I added it. //
			cout << op1 << " / " << op2 << " = " << op1 / op2 << endl; // Updated the " * " to be a " / " per the operation. //
		}  // Added the brace to finish this If statement //

		cout << "Do you wish to evaluate another expression? " << endl;
		cout << endl; // Added to help with the program's UI look.  It bothered me. //
		cout << "Type Y / y for Yes or N / n for No. " << endl; // Added to help with the program's UI functionality //
		cout << endl; // Added to help with the program's UI look.  It bothered mne. //

		cin >> answer;

		if ((answer == 'n') || (answer == 'N')) {  // Created a new If and Or statement to exit our calculator program //

			cout << "Program has terminated.";  // Added this cout message //

			return 0;  // Added a return 0 in order to exit this code //

		}  // Added this brace to end the above If statement //

	} // While End //

} // Main End //